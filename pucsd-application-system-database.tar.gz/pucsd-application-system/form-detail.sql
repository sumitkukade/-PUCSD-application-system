
/*--------------Bonafide field-----------*/


CREATE TABLE applicationPurposeDomain (
  applicationPurpose varchar(255) NOT NULL,
  CONSTRAINT applicationPurposeDomain_unique UNIQUE (applicationPurpose)
); 

/* student insert in table the trigger fired. if valid application the it store into the corroseponding table*/

CREATE TABLE applicationForm (
  rollNumber varchar(15) NOT NULL,
  requestId bigint NOT NULL,
  appId varchar(5) NOT NuLL,
  applicationPurpose text,
  CONSTRAINT applicationForm_pk Primary key(rollNumber,appId,requestId),
  Foreign Key(rollNumber) References studentDetailsDomain(rollNumber)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(appId) References applicationDomain(appId)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/*--------------------------------------------------------------------*/
CREATE TABLE officeContactDetails (
phoneNo text NOT NULL,
hodEmail text NOT NULL,
officeEmail text NOT NULL
);
/*--------------------------------------------------------------------*/

CREATE TABLE applicationRejectRemark (
  applicationRejectId bigInt NOT NULL AUTO_INCREMENT,
  rollNumber varchar(15) NOT NULL,
  appId varchar(5) NOT NULL,
  applicationRemark text NOT NULL,
  applicationPurpose text,
  applicationTimeStamp timestamp NOT NULL,
  CONSTRAINT applicationRejectRemark_pk Primary Key(applicationRejectId),
  Foreign Key(rollNumber) References studentDetailsDomain(rollNumber)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(appId) References applicationDomain(appId)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/*--------------------------------------------------------------------*/

CREATE TABLE applicationCollectedListForStaff (
  applicationCollectId bigInt NOT NULL Primary Key AUTO_INCREMENT,
  rollNumber varchar(15) NOT NULL,
  refNo integer,
  appId varchar(5) NOT NULL,
  applicationPdf blob,
  applicationTimeStamp timestamp NOT NULL,
  applicationPurpose text NOT NULL,
  Foreign Key(rollNumber) References studentDetailsDomain(rollNumber)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(appId) References applicationDomain(appId)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/*--------------------------------------------------------------------*/


/*--------------------------------------------------------------------*/

CREATE TABLE applicationFormForStaff (
  requestId bigInt NOT NULL Primary Key AUTO_INCREMENT,
  rollNumber varchar(15) NOT NULL,
  appId varchar(5) NOT NuLL,
  applicationPurpose text,
  refNo integer,
  rpNo integer,
  uniqueNo integer,
  stayVisaUpTo integer,
  regularOrBacklog text,
  examDate text,
  resultDate text,
  Foreign Key(rollNumber) References studentDetailsDomain(rollNumber)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(appId) References applicationDomain(appId)
  ON DELETE RESTRICT ON UPDATE CASCADE
);


/*--------------------------------------------------------------------*/

/* if application for feesStructureForm the all information of the student store in that table by the trigger */

CREATE TABLE feesStructureForm (
   rollNumber varchar(15) NOT NULL,
   fname text NOT NULL,
   mname text,
   lname text NOT NULL,
   courseId varchar(3) NOT NULL,
   semId varchar(1) NOT NULL,
   tutionFee integer NOT NULL,
   labFee integer NOT NULL,
   otherFee integer NOT NULL,
   Total integer NOT NULL,
   currdate date NOT NULL
);

CREATE TABLE aux_studentApplicationCount (
   requestId bigint NOT NULL,
   rollNumber varchar(15) NOT NULL,
   appId varchar(5) NOT NULL,
   appCnt integer NOT NULL,
   Foreign Key(requestId) References requestindex(requestId)
   ON DELETE RESTRICT ON UPDATE CASCADE,
   Foreign Key(rollNumber) References studentDetailsDomain(rollNumber)
   ON DELETE RESTRICT ON UPDATE CASCADE,
   Foreign Key(appId) References applicationDomain(appId)
   ON DELETE RESTRICT ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS startAndfinalStateDomain (
   applicationState varchar(40) NOT NULL,
   Constraint pk_startAndfinalStateDomain Primary Key(applicationState),
   Foreign key(applicationState) References applicationStateDomain(applicationState)
   ON DELETE RESTRICT ON UPDATE CASCADE
);

CREATE TABLE auxApplicationForm (
  rollNumber varchar(15) NOT NULL,
  appId varchar(5) NOT NULL,
  Constraint pk_auxApplicationForm Primary key(rollNumber,appId),
  Foreign Key(rollNumber) References studentDetailsDomain(rollNumber)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(appId) References applicationDomain(appId)
  ON DELETE RESTRICT ON UPDATE CASCADE
);


/* this PROCEDURE for feesStructure insertion */

delimiter |


CREATE PROCEDURE applicationProcess.insertInFeeStructure(IN rollnumber varchar(15), IN fname text,IN mname text,IN lname text,IN course varchar(5),IN studentDomain int,IN categoryId varchar(5))

BEGIN
  declare count int;
  IF course = (select distinct courseId from courseDomain order by courseId asc limit 1)  THEN
    set count = 1;
    while count <= 6 do
      if(studentDomain = 1) then
         insert into feesStructureForm(rollNumber,fname,mname,lname,courseId,semId,tutionFee,labFee,otherFee,Total,currdate) values(rollnumber,fname,mname,lname,course,count,(select tutionFee from feesStructureForInternationalStudentDomain where courseId=course and semId = count and category = categoryId),(select labFee from feesStructureForInternationalStudentDomain where courseId=course and semId = count and category = categoryId),(select otherFee from feesStructureForInternationalStudentDomain where courseId=course and semId = count and category = categoryId),(select tutionFee+labFee+otherFee from feesStructureForInternationalStudentDomain where courseId=course and semId = count and category = categoryId),NOW());
      else if(studentDomain = 2) then
         insert into feesStructureForm(rollNumber,fname,mname,lname,courseId,semId,tutionFee,labFee,otherFee,Total,currdate) values(rollnumber,fname,mname,lname,course,count,(select tutionFee from feesStructureNonMaharashtrianDomain where courseId=course and semId = count and category = categoryId),(select labFee from feesStructureNonMaharashtrianDomain where courseId=course and semId = count and category = categoryId),(select otherFee from feesStructureNonMaharashtrianDomain where courseId=course and semId = count and category = categoryId),(select tutionFee+labFee+otherFee from feesStructureNonMaharashtrianDomain where courseId=course and semId = count and category = categoryId),NOW());
      else
         insert into feesStructureForm(rollNumber,fname,mname,lname,courseId,semId,tutionFee,labFee,otherFee,Total,currdate) values(rollnumber,fname,mname,lname,course,count,(select tutionFee from feesStructureDomain where courseId=course and semId = count and category = categoryId),(select labFee from feesStructureDomain where courseId=course and semId = count and category = categoryId),(select otherFee from feesStructureDomain where courseId=course and semId = count and category = categoryId),(select tutionFee+labFee+otherFee from feesStructureDomain where courseId=course and semId = count and category = categoryId),NOW());
      end if;
      end if;
       set count = count + 1;
    end while;
  END IF;
  IF course = (select distinct courseId from courseDomain order by courseId desc limit 1)  THEN
    set count = 1;
    while count <= 4 do
      if(studentDomain = 1) then
         insert into feesStructureForm(rollNumber,fname,mname,lname,courseId,semId,tutionFee,labFee,otherFee,Total,currdate) values(rollnumber,fname,mname,lname,course,count,(select tutionFee from feesStructureForInternationalStudentDomain where courseId=course and semId = count and category = categoryId),(select labFee from feesStructureForInternationalStudentDomain where courseId=course and semId = count and category = categoryId),(select otherFee from feesStructureForInternationalStudentDomain where courseId=course and semId = count and category = categoryId),(select tutionFee+labFee+otherFee from feesStructureForInternationalStudentDomain where courseId=course and semId = count and category = categoryId),NOW());
      else if(studentDomain = 2) then
         insert into feesStructureForm(rollNumber,fname,mname,lname,courseId,semId,tutionFee,labFee,otherFee,Total,currdate) values(rollnumber,fname,mname,lname,course,count,(select tutionFee from feesStructureNonMaharashtrianDomain where courseId=course and semId = count and category = categoryId),(select labFee from feesStructureNonMaharashtrianDomain where courseId=course and semId = count and category = categoryId),(select otherFee from feesStructureNonMaharashtrianDomain where courseId=course and semId = count and category = categoryId),(select tutionFee+labFee+otherFee from feesStructureNonMaharashtrianDomain where courseId=course and semId = count and category = categoryId),NOW());
      else
         insert into feesStructureForm(rollNumber,fname,mname,lname,courseId,semId,tutionFee,labFee,otherFee,Total,currdate) values(rollnumber,fname,mname,lname,course,count,(select tutionFee from feesStructureDomain where courseId=course and semId = count and category = categoryId),(select labFee from feesStructureDomain where courseId=course and semId = count and category = categoryId),(select otherFee from feesStructureDomain where courseId=course and semId = count and category = categoryId),(select tutionFee+labFee+otherFee from feesStructureDomain where courseId=course and semId = count and category = categoryId),NOW());
      end if;
      end if;
       set count = count + 1;
    end while;
  END IF;

END;

/* By that trigger all applicationform result store corrosepodint with that table */

CREATE TRIGGER applicationProcess.triggerForFormDetails after insert on applicationProcess.applicationForm
FOR EACH ROW
  BEGIN
    set @appIndex = (select appIndex from applicationDomain where appId = NEW.appId);
    set @fname  = (select fname from applicationProcess.studentDetailsDomain where rollNumber = NEW.rollNumber);
    set @mname = (select mname from applicationProcess.studentDetailsDomain where rollNumber = NEW.rollNumber);
    set @lname  = (select lname from applicationProcess.studentDetailsDomain where rollNumber = NEW.rollNumber);
    set @courseName = (select courseId from applicationProcess.studentDetailsDomain where rollNumber=NEW.rollNumber);
    set @semId = (select semId from applicationProcess.studentDetailsDomain where rollNumber=NEW.rollNumber);
    set @year = (select year from applicationProcess.courseSemesterDomain where courseId = @courseName and semId = @semId);
    set @DOB = (select dateOfBirth from applicationProcess.studentDetailsDomain where rollNumber = NEW.rollNumber);
    set @internationalStudent = (select NEW.rollNumber in (select rollNumber from internationalStudentInformationDomain));
    set @domicile = (select domicile from applicationProcess.studentDetailsDomain where rollNumber = NEW.rollNumber);
    set @category = (select category from applicationProcess.studentDetailsDomain where rollNumber = NEW.rollNumber);
    set @isinternationalStudent = (select NEW.rollNumber in (select rollNumber from internationalStudentInformationDomain));
    set @appcnt = (select appcnt from applicationProcess.studentApplicationCount where appId = NEW.appId and rollNumber = NEW.rollNumber order by appcnt desc limit 1);
    set @applimit = (select appcnt from applicationProcess.applicationCntDomain where appId = NEW.appId);
    if(@applimit = @appcnt) then
       set @appCntExists = (select @appcnt in (select appcnt from applicationProcess.aux_studentApplicationCount where rollNumber = NEW.rollNumber and appId =NEW.appId));
       insert into applicationProcess.aux_studentApplicationCount(requestId,rollNumber,appId,appcnt) values(NEW.requestId,NEW.rollNumber,NEW.appId,@appcnt);
      if(@appCntExists = 0) then
         delete from auxApplicationForm where rollNumber = NEW.rollNumber and appId = NEW.appId;
         insert into auxApplicationForm(rollNumber,appId) values(NEW.rollNumber,NEW.appId);
        insert into userInputDatabase.outputErrorMsgs(requestId,timet,msgId,msg) values(NEW.requestId,NOW(),(select msgId from userInputDatabase.messagesForUsersDomain where msgId=(select applicationState from applicationProcess.startAndfinalStateDomain order by applicationState desc limit 1)),(select msgAboutUserAuthentication from userInputDatabase.messagesForUsersDomain where msgId=(select applicationState from applicationProcess.startAndfinalStateDomain order by applicationState desc limit 1)));
      end if;
    end if;
    if(@appIndex = 1) then
        set @applicationPurposeExists = (select count(applicationPurpose) from applicationForm where rollNumber =NEW.rollNumber and appId = NEW.appId and applicationPurpose = NEW.applicationPurpose);
        if(@applicationPurposeExists > 1) then
           insert into userInputDatabase.outputErrorMsgs(requestId,timet,msgId,msg) values(NEW.requestId,NOW(),(select msgId from userInputDatabase.messagesForUsersDomain where msgId=(select applicationState from applicationProcess.startAndfinalStateDomain order by applicationState desc limit 1)),(select msgForState from userInputDatabase.messagesForUsersDomain where msgId=(select applicationState from applicationProcess.startAndfinalStateDomain order by applicationState desc limit 1)));
        end if;
    else
      set @applicationExist = (select count(rollNumber) from applicationProcess.applicationForm where rollNumber = NEW.rollNumber and appId = NEW.appId);
      if(@applicationExist > 1) then
           insert into userInputDatabase.outputErrorMsgs(requestId,timet,msgId,msg) values(NEW.requestId,NOW(),(select msgId from userInputDatabase.messagesForUsersDomain where msgId=(select applicationState from applicationProcess.startAndfinalStateDomain order by applicationState desc limit 1)),(select msgForState from userInputDatabase.messagesForUsersDomain where msgId=(select applicationState from applicationProcess.startAndfinalStateDomain order by applicationState desc limit 1)));
      end if;
    end if;
    if(@appIndex = 3) then
       if(@domicile = 0) then
          if(@internationalStudent = 1) then
             call insertInFeeStructure(NEW.rollNumber,@fname,@mname,@lname,@courseName,1,"OPEN");
          else
             call insertInFeeStructure(NEW.rollNumber,@fname,@mname,@lname,@courseName,2,"OPEN");
          end if;
       else
          call insertInFeeStructure(NEW.rollNumber,@fname,@mname,@lname,@courseName,0,@category);
       end if;
    end if;
  END;


CREATE TRIGGER applicationProcess.validateRefNo after insert on applicationFormForStaff
FOR EACH ROW
  BEGIN
     set @validateRefNo = (select NEW.refNo in (select refNo from applicationFormForStaff where rollNumber != NEW.rollNumber));
     if(@validateRefNo = 1) then
           insert into userInputDatabase.outputErrorMsgs(requestId,timet,msgId,msg) values(NEW.requestId,NOW(),(select msgId from userInputDatabase.messagesForUsersDomain where msgId="ERR"),(select msgForAcomplish from userInputDatabase.messagesForUsersDomain where msgId="ERR"));
     end if;
  END;

 |
delimiter ;
