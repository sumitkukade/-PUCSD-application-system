DROP TRIGGER IF EXISTS applicationProcess.triggerApplicationRequestByStaff;

/*it check for studentApplicationQueue if student is requested for his application the staff do the application process. the all state are stored within its requestId */


delimiter |


CREATE TRIGGER applicationProcess.triggerApplicationRequestByStaff after insert on applicationRequestByStaff
FOR EACH ROW
  BEGIN
    set @string = NEW.params;
    set @studentUserId = (select rollnumber from applicationProcess.studentApplicationQueue where requestId = (select min(requestId) from applicationProcess.studentApplicationQueue));
    set @studentApplicationQueueLen = (select count(*) from applicationProcess.studentApplicationQueue);
    set @len  = (select length(@string)+1 - (select length(replace(@string,",",""))));
    set @applicationId = (select applicationProcess.split_str(@string,",",@len-(@len-1)));
    set @startState = (select applicationProcess.split_str(@string,",",@len-(@len-2)));
    set @endState = (select applicationProcess.split_str(@string,",",@len-(@len-3)));
    set @applicationuserID = (select applicationProcess.split_str(@string,",",@len-(@len-4)));
    set @validState = (select @startState in (select toState from aux_studentAndState where appId = NEW.appId or rollNumber = @applicationuserID));
    set @validRequestFromStaff = (select @startState in (select staffActionFrom from staffActionDomain));
    set @validRequestToStaff = (select @endState in (select staffActionTo from staffActionDomain));
    set @applicationFormodification = (select @endState = (select applicationState from applicationProcess.modificationStateDomain order by applicationState limit 1));
    set @ApplicationRejectedByOffice = (select @startState = (select applicationState from applicationProcess.startAndfinalStateDomain order by applicationState limit 1));
    set @appIDX = (select appindex  from applicationProcess.applicationDomain  where appId = NEW.appId);

    if(@validRequestFromStaff = 1 and @validRequestToStaff = 1) then
        set @duplicatestate  =(select NEW.userId in (select staffId from staffDetailsDomain where staffId in (select userId from aux_requestStateTransitions where  fromState = (select applicationProcess.split_str(@string,",",@len-(@len-2))) and toState = @endState and appId = @applicationId and applicationPurpose = NEW.applicationPurpose)));
        if(@studentApplicationQueueLen > 0 and @validState = 1) then
           set @finishState = (select applicationState from applicationProcess.startAndfinalStateDomain order by applicationState desc limit 1,1);
           if(@applicationFormodification = 1 and (@appIDX = 1 or @appIDX = 3)) then
                 if(@appIDX = 3) then
                    set @appPurpose = (select applicationPurpose from applicationProcess.applicationFormForStaff where rollNumber = @applicationuserID and appId = NEW.appId order by requestId desc limit 1);
                else
                    set @appPurpose = (select applicationPurpose from applicationProcess.applicationFormForStaff where rollNumber = @applicationuserID and appId = NEW.appId order by requestId desc limit 1);
                    set @validAppPurpose = (select @applicationPurpose in (select  applicationPurpose from applicationForm where rollNumber = @applicationuserID and appId = NEW.appId));
                end if;
               
                 set @isappPurposeNULL = (select @appPurpose IS NULL);
                 if((@appIDX = 3) and @isappPurposeNULL = 0 ) then
                      update applicationProcess.applicationForm set applicationPurpose = @appPurpose where rollNumber = @applicationuserID and appId = NEW.appId;
                 else if(@appIDX = 1 and @isappPurposeNULL = 0 and @validAppPurpose = 0) then
                      update applicationProcess.applicationForm set applicationPurpose = @appPurpose where rollNumber = @applicationuserID and appId = NEW.appId and applicationPurpose = NEW.remark;
                      update applicationProcess.aux_studentAndState set applicationPurpose = @appPurpose where rollNumber = @applicationuserID and appId = NEW.appId and applicationPurpose = NEW.remark;
                      update applicationProcess.studentApplicationQueue set applicationPurpose = @appPurpose where rollnumber = @applicationuserID and appId = NEW.appId and applicationPurpose = NEW.remark;
                       update applicationProcess.aux_requestStateTransitions set applicationPurpose = @appPurpose where userId = NEW.userId and applicationPurpose = NEW.remark;
                 else if(@validAppPurpose = 1) then
                      insert into userInputDatabase.outputErrorMsgs(requestId,timet,msgId,msg) values(NEW.requestId,NEW.requestArrivalTime,(select msgId from userInputDatabase.messagesForUsersDomain where msgId=@endState),(select msgForState from userInputDatabase.messagesForUsersDomain where msgId=@endState));
                 end if;
                 end if;
                 end if;
           else if(@ApplicationRejectedByOffice = 1) then
                if(@appIDX = 1) then
                  insert into  applicationProcess.applicationRejectRemark(rollNumber,appId,applicationRemark,applicationTimeStamp,applicationPurpose) values(@applicationuserID,NEW.appId,NEW.remark,NOW(),NEW.applicationPurpose);
                else
                  insert into  applicationProcess.applicationRejectRemark(rollNumber,appId,applicationRemark,applicationTimeStamp) values(@applicationuserID,NEW.appId,NEW.remark,NOW());
                end if;
           end if;
           end if;
          if(@appIDX = 1) then
              insert into aux_studentAndState(requestId,rollNumber,fromState,toState,appId,iplog,applicationPdf,applicationPurpose) values(NEW.requestId,@applicationuserID,@startState,@endState,NEW.appId,NEW.iplog,NEW.applicationPdf,NEW.applicationPurpose);
              insert into applicationProcess.studentApplicationQueue(requestId,rollnumber,appId,requestArrivalTime,fromState,toState,applicationPurpose) values(NEW.requestId,@applicationuserID,NEW.appId,NOW(),@startState,@endState,NEW.applicationPurpose);
              insert into applicationProcess.requestStateTransitions(requestId,fromState,toState,userId,requestArrivalTime,remark,params,applicationPurpose) values(NEW.requestId,@startState,@endState,NEW.userId,NEW.requestArrivalTime,NEW.remark,@string,NEW.applicationPurpose);
              insert into applicationProcess.aux_requestStateTransitions(requestId,fromState,toState,userId,appId,requestArrivalTime,remark,params,applicationPurpose) values(NEW.requestId,@startState,@endState,NEW.userId,NEW.appId,NEW.requestArrivalTime,NEW.remark,@string,NEW.applicationPurpose);
              insert into userInputDatabase.outputResults(requestId,timet,output) values(NEW.requestId,NOW(),(select concat(@startState,",",@endState)));
           else
              insert into aux_studentAndState(requestId,rollNumber,fromState,toState,appId,iplog,applicationPdf) values(NEW.requestId,@applicationuserID,@startState,@endState,NEW.appId,NEW.iplog,NEW.applicationPdf);
              insert into applicationProcess.studentApplicationQueue(requestId,rollnumber,appId,requestArrivalTime,fromState,toState) values(NEW.requestId,@applicationuserID,NEW.appId,NOW(),@startState,@endState);
              insert into applicationProcess.requestStateTransitions(requestId,fromState,toState,userId,requestArrivalTime,remark,params) values(NEW.requestId,@startState,@endState,NEW.userId,NEW.requestArrivalTime,NEW.remark,@string);
              insert into applicationProcess.aux_requestStateTransitions(requestId,fromState,toState,userId,appId,requestArrivalTime,remark,params) values(NEW.requestId,@startState,@endState,NEW.userId,NEW.appId,NEW.requestArrivalTime,NEW.remark,@string);
              insert into userInputDatabase.outputResults(requestId,timet,output) values(NEW.requestId,NOW(),(select concat(@startState,",",@endState)));
           end if;
           if(@endState = @finishState) then
                 set @appidx = (select appindex from applicationProcess.applicationDomain where appId = NEW.appId);
                 set @requestFinishedSuccessfully = (select @startState = (select applicationState from applicationProcess.modificationStateDomain order by applicationState desc limit 1));
                 if(@requestFinishedSuccessfully = 1) then
                     insert into applicationProcess.studentApplicationCount(requestId,rollnumber,appId) values(NEW.requestId,@applicationuserID,NEW.appId);
                     if(@appidx = 1) then
                       insert into  applicationProcess.applicationCollectedListForStaff(rollNumber,refNo,appId,applicationPdf,applicationTimeStamp,applicationPurpose) values(@applicationuserID,(select refNo from applicationProcess.applicationFormForStaff where rollNumber = @applicationuserID and appId = NEW.appId order by requestId desc limit 1),NEW.appId,(select applicationPdf from aux_studentAndState where fromState = (select applicationState from applicationProcess.modificationStateDomain order by applicationState desc limit 1,1) and toState = (select staffActionTo from applicationProcess.staffActionDomain where staffActionFrom = (select applicationState from applicationProcess.modificationStateDomain order by applicationState desc limit 1,1) order by staffActionTo desc limit 1) and rollNumber = @applicationuserID and appId = NEW.appId and applicationPurpose = NEW.applicationPurpose order by requestId desc limit 1),NOW(),NEW.applicationPurpose);
                     else
                       insert into  applicationProcess.applicationCollectedListForStaff(rollNumber,refNo,appId,applicationPdf,applicationTimeStamp) values(@applicationuserID,(select refNo from applicationProcess.applicationFormForStaff where rollNumber = @applicationuserID and appId = NEW.appId order by requestId desc limit 1),NEW.appId,(select applicationPdf from aux_studentAndState where fromState = (select applicationState from applicationProcess.modificationStateDomain order by applicationState desc limit 1,1) and toState = (select staffActionTo from applicationProcess.staffActionDomain where staffActionFrom = (select applicationState from applicationProcess.modificationStateDomain order by applicationState desc limit 1,1) order by staffActionTo desc limit 1) and rollNumber = @applicationuserID and appId = NEW.appId order by requestId desc limit 1),NOW());
                     end if;
                     update applicationProcess.studentApplicationCount set appcnt = appcnt + 1 where rollnumber = @applicationuserID and appId = NEW.appId;
                  end if;
                  if(@appidx = 3) then
                       delete from  applicationProcess.feesStructureForm where rollnumber = @applicationuserID;
                  end if;
                  if(@appidx = 1) then
                     delete from studentApplicationQueue where rollNumber = @applicationuserID and appId = NEW.appId and applicationPurpose = NEW.applicationPurpose;
                     delete from aux_studentAndState where rollNumber = @applicationuserID and appId = NEW.appId and applicationPurpose = NEW.applicationPurpose;
                     delete from applicationFormForStaff where rollNumber = @applicationuserID and appId = NEW.appId and applicationPurpose = NEW.applicationPurpose;
                     delete from aux_requestStateTransitions where requestId not in (select requestId from aux_studentAndState);
                     delete from requestStateTransitions where requestId not in (select requestId from aux_studentAndState);
                     delete from applicationRequests where userId = @applicationuserID and appId = NEW.appId and applicationPurpose = NEW.applicationPurpose;
                     delete from applicationForm where rollNumber = @applicationuserID and appId = NEW.appId and applicationPurpose = NEW.applicationPurpose;
                  else
                     delete from studentApplicationQueue where rollNumber = @applicationuserID and appId = NEW.appId;
                     delete from aux_studentAndState where rollNumber = @applicationuserID and appId = NEW.appId;
                     delete from applicationFormForStaff where rollNumber = @applicationuserID and appId = NEW.appId;
                     delete from aux_requestStateTransitions where requestId not in (select requestId from aux_studentAndState);
                     delete from requestStateTransitions where requestId not in (select requestId from aux_studentAndState);
                     delete from applicationRequests where userId = @applicationuserID and appId = NEW.appId;
                     delete from applicationForm where rollNumber = @applicationuserID and appId = NEW.appId;
                 end if;
           end if;
       else
        insert into userInputDatabase.outputErrorMsgs(requestId,timet,msgId,msg) values(NEW.requestId,NEW.requestArrivalTime,(select msgId from userInputDatabase.messagesForUsersDomain where msgId=@endState),(select msgForAcomplish from userInputDatabase.messagesForUsersDomain where msgId=@endState));
       end if;
    else
      insert into userInputDatabase.outputErrorMsgs(requestId,timet,msgId,msg) values(NEW.requestId,NEW.requestArrivalTime,(select msgId from     userInputDatabase.messagesForUsersDomain where msgId=@startState),(select msgAboutUserAuthentication from userInputDatabase.messagesForUsersDomain where msgId=@startState));
    end if;
  END;


  |
delimiter ;
