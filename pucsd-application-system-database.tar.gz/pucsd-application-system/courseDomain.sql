insert into courseDomain(courseId,year) values("MCA",1),("MCA",2),("MCA",3),("MSC",1),("MSC",2);
