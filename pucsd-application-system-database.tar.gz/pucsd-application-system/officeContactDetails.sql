insert into officeContactDetails(phoneNo,hodEmail,officeEmail) values("020-25601446","hodocs@unipune.ac.in","pucsd@pun.unipune.ac.in");
