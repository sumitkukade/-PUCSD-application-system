DROP TRIGGER IF EXISTS applicationProcess.triggerForUpdate;
DROP TRIGGER IF EXISTS applicationProcess.triggerForUpdateRequestId;

/* this trigger for update the record as per paramete by student gives in inputRequests table */


delimiter |


CREATE TRIGGER applicationProcess.triggerForUpdate after insert on applicationProcess.aux_applicationRequestsUpdate
FOR EACH ROW
  BEGIN
    set @string = NEW.params;
    set @len  = (select length(@string)+1 - (select length(replace(@string,",",""))));
    set @startState = (select applicationProcess.split_str(@string,",",@len-(@len-2)));
    set @newStartState = (select applicationProcess.split_str(@string,",",@len-(@len-3)));
    set @endState = (select applicationProcess.split_str(@string,",",@len-(@len-4)));
    set @newEndState = (select applicationProcess.split_str(@string,",",@len-(@len-5)));
    set @validStartState = (select @startState in (select fromState from requestStateTransitions where userId=NEW.userId or userId=@userId));
    set @validEndState = (select @endState in (select toState from requestStateTransitions where userId=NEW.userId or userId=@userId));
    set @requestId = (select requestId from applicationProcess.requestStateTransitions where fromState = @startState and toState = @endState order by requestId desc limit 1);
    set @remark = (select remark from applicationProcess.applicationRequests where requestId = @requestId);
    set @tableIdx = (select tableIndex from userInputDatabase.tableIdDomain where tableId = (select tableId from userInputDatabase.inputRequests where requestId = @requestId));
    set @iplog = (select iplog from userInputDatabase.inputRequests where requestId = @requestId);
    set @applicationPdf = (select applicationPdf from userInputDatabase.inputRequests where requestId = @requestId);
    if(@validStartState = 1 and @validEndState = 1) then
        delete from applicationProcess.applicationRequests where requestId = @requestId;
        delete from applicationProcess.applicationRequestByStaff where requestId = @requestId;
        delete from applicationProcess.requestStateTransitions where requestId = @requestId;
        delete from userInputDatabase.outputResults where requestId = @requestId;
        delete from userInputDatabase.outputErrorMsgs where requestId = @requestId;
        set @string1 = (select concat_ws(",",NEW.appId,@newStartState,@newEndState));
        if(@tableIdx = 1) then
           insert into applicationProcess.applicationRequests(requestId,appId,userId,requestArrivalTime,remark,params,iplog,applicationPdf) values(@requestId,NEW.appId,NEW.userId,NOW(),@remark,@string1,@iplog,@applicationPdf);
        else if(@tableIdx = 2) then
           insert into applicationProcess.applicationRequestByStaff(requestId,appId,userId,requestArrivalTime,remark,params,iplog,applicationPdf) values(@requestId,NEW.appId,NEW.userId,NOW(),@remark,@string1,@iplog,@applicationPdf);
        end if;
        end if;
     else
        insert into userInputDatabase.outputErrorMsgs(requestId,timet,msgId,msg) values(NEW.requestId,NEW.requestArrivalTime,(select msgId from userInputDatabase.messagesForUsersDomain where msgId=@startState),(select msgForAcomplish from userInputDatabase.messagesForUsersDomain where msgId=@startState));
     end if;
  END;


CREATE TRIGGER applicationProcess.triggerForUpdateRequestId after insert on applicationProcess.aux_applicationRequestsUpdateRequestId
FOR EACH ROW
  BEGIN
    set @string = NEW.params;
    set @len  = (select length(@string)+1 - (select length(replace(@string,",",""))));
    set @startState = (select applicationProcess.split_str(@string,",",@len-(@len-3)));
    set @newStartState = (select applicationProcess.split_str(@string,",",@len-(@len-4)));
    set @endState = (select applicationProcess.split_str(@string,",",@len-(@len-5)));
    set @newEndState = (select applicationProcess.split_str(@string,",",@len-(@len-6)));
    set @validStartState = (select @startState in (select fromState from requestStateTransitions where userId=NEW.userId or userId=@userId));
    set @validEndState = (select @endState in (select toState from requestStateTransitions where userId=NEW.userId or userId=@userId));
    set @tableIdx = (select tableIndex from userInputDatabase.tableIdDomain where tableId = (select tableId from userInputDatabase.inputRequests where requestId = NEW.requestId));
    set @remark = (select remark from applicationProcess.applicationRequests where requestId = NEW.requestId);
    set @iplog = (select iplog from userInputDatabase.inputRequests where requestId = NEW.requestId);
    if(@validStartState = 1 and @validEndState = 1) then
        delete from applicationProcess.applicationRequests where requestId = NEW.requestId;
        delete from applicationProcess.applicationRequestByStaff where requestId = NEW.requestId;
        delete from applicationProcess.requestStateTransitions where requestId = NEW.requestId;
        delete from userInputDatabase.outputResults where requestId = NEW.requestId;
        delete from userInputDatabase.outputErrorMsgs where requestId = NEW.requestId;
        set @string1 = (select concat_ws(",",NEW.appId,@newStartState,@newEndState));
        set @userIdExistsInRequestStateTransitions = (select NEW.userId in (select userId from applicationProcess.requestStateTransitions where requestId = NEW.requestId and fromState = @startState and toState = @endState));
        if(@tableIdx = 1) then
           insert into applicationProcess.applicationRequests(requestId,appId,userId,requestArrivalTime,remark,params,iplog) values(NEW.requestId,NEW.appId,NEW.userId,NOW(),@remark,@string1,@iplog);
        else if(@tableIdx = 2) then
           insert into applicationProcess.applicationRequestByStaff(requestId,appId,userId,requestArrivalTime,remark,params,iplog) values(NEW.requestId,NEW.appId,NEW.userId,NOW(),@remark,@string1,@iplog);
        end if;
        end if;
     else
        insert into userInputDatabase.outputErrorMsgs(requestId,timet,msgId,msg) values(NEW.requestId,NEW.requestArrivalTime,(select msgId from userInputDatabase.messagesForUsersDomain where msgId=@startState),(select msgForAcomplish from userInputDatabase.messagesForUsersDomain where msgId=@startState));
     end if;
  END;


  |
delimiter ;
