insert into modificationStateDomain(applicationState) values("ApplicationModification"),("ModificationSuccessfully"),("RequestFinishedSuccessfully");
