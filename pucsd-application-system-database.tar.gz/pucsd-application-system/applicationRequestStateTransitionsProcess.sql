DROP TRIGGER IF EXISTS applicationProcess.insertInRequestStateTransitions;


delimiter |

CREATE TRIGGER applicationProcess.insertInRequestStateTransitions after insert on applicationProcess.applicationRequests
FOR EACH ROW
  BEGIN
    set @string = NEW.params;
    set @len  = (select length(@string)+1 - (select length(replace(@string,",",""))));
    set @appcntId = (select applicationProcess.split_str(@string,",",@len-(@len-1)));
    set @startState = (select applicationProcess.split_str(@string,",",@len-(@len-2)));
    set @endState = (select applicationProcess.split_str(@string,",",@len-(@len-3)));
    set @validuserId = (select userId from applicationProcess.applicationRequests where appId = @appcntId order by userId limit 1);
    set @validState = (select @startState in (select toState from applicationProcess.aux_requestStateTransitions where userId = NEW.userId and appId = @appcntId));
    set @validRequestFromStudent = (select @startState in (select studentActionFrom from studentActionDomain));
    set @validRequestToStudent = (select @endState in (select studentActionTo from studentActionDomain));
    set @applicationSubmitStatus = (select studentActionTo from applicationProcess.studentActionDomain where studentActionTo in (select staffActionFrom from applicationProcess.staffActionDomain) order by studentActionTo asc limit 1);
   set @rollNumberExistInapplicationForm = (select NEW.userId in (select rollNumber from applicationProcess.auxApplicationForm where rollNumber = NEW.userId and appId = NEW.appId));
   set @studentApplyId = (select NEW.userId in (select rollNumber from applicationProcess.applicationForm where rollNumber = NEW.userId and appId = NEW.appId));
    insert into applicationProcess.g(a) values(@studentApplyId);
    set @appIdx = (select appindex from applicationDomain where appId = NEW.appId);
    if(@validRequestFromStudent = 1 and @validRequestToStudent = 1) then
      if(@appIdx = 1) then
          set @duplicateState = (select NEW.userId in (select userId from aux_requestStateTransitions where userId = NEW.userId and fromState = (select applicationProcess.split_str(@string,",",@len-(@len-2))) and toState = @endState and appId = @appcntId and applicationPurpose = NEW.applicationPurpose));
       else
          set @duplicateState = (select NEW.userId in (select userId from aux_requestStateTransitions where userId = NEW.userId and fromState = (select applicationProcess.split_str(@string,",",@len-(@len-2))) and toState = @endState and appId = @appcntId));
      end if;
       if(@duplicateState = 1) then
         insert into userInputDatabase.outputErrorMsgs(requestId,timet,msgId,msg) values(NEW.requestId,NEW.requestArrivalTime,(select msgId from userInputDatabase.messagesForUsersDomain where msgId=@startState),(select msgForState from userInputDatabase.messagesForUsersDomain where msgId=@startState));
       else
          if(@rollNumberExistInapplicationForm = 1) then
               delete from applicationForm where rollNumber = NEW.userId and appId = NEW.appId;
          else if(@startState = (select applicationState from startAndfinalStateDomain order by applicationState desc limit 1) and @studentApplyId = 1) then
               delete from applicationProcess.applicationRequestByStaff;
               if(@appIdx = 1) then 
                  insert into aux_studentAndState(requestId,rollNumber,fromState,toState,appId,applicationPurpose) values(NEW.requestId,NEW.userId,@startState,@endState,@appcntId,NEW.applicationPurpose);
                  insert into applicationProcess.aux_requestStateTransitions(requestId,fromState,toState,userId,appId,requestArrivalTime,remark,params,applicationPurpose) values(NEW.requestId,@startState,@endState,NEW.userId,@appcntId,NEW.requestArrivalTime,NEW.remark,@string,NEW.applicationPurpose);
                  insert into applicationProcess.requestStateTransitions(requestId,fromState,toState,userId,requestArrivalTime,remark,params,applicationPurpose) values(NEW.requestId,@startState,@endState,NEW.userId,NEW.requestArrivalTime,NEW.remark,@string,NEW.applicationPurpose);
                  insert into userInputDatabase.outputResults(requestId,timet,output) values(NEW.requestId,NOW(),(select concat(@startState,",",@endState)));
               else
                  insert into aux_studentAndState(requestId,rollNumber,fromState,toState,appId) values(NEW.requestId,NEW.userId,@startState,@endState,@appcntId);
                  insert into applicationProcess.aux_requestStateTransitions(requestId,fromState,toState,userId,appId,requestArrivalTime,remark,params) values(NEW.requestId,@startState,@endState,NEW.userId,@appcntId,NEW.requestArrivalTime,NEW.remark,@string);
                  insert into applicationProcess.requestStateTransitions(requestId,fromState,toState,userId,requestArrivalTime,remark,params) values(NEW.requestId,@startState,@endState,NEW.userId,NEW.requestArrivalTime,NEW.remark,@string);
                  insert into userInputDatabase.outputResults(requestId,timet,output) values(NEW.requestId,NOW(),(select concat(@startState,",",@endState)));
               end if;
         else if(@validState = 1 and @studentApplyId = 1) then
              if(@endState = @applicationSubmitStatus) then
                if(@appIdx = 1) then
                  insert into applicationProcess.studentApplicationQueue(requestId,rollnumber,appId,requestArrivalTime,fromState,toState,applicationPurpose) values(NEW.requestId,NEW.userId,NEW.appId,NOW(),@startState,@endState,NEW.applicationPurpose);
                else
                  insert into applicationProcess.studentApplicationQueue(requestId,rollnumber,appId,requestArrivalTime,fromState,toState) values(NEW.requestId,NEW.userId,NEW.appId,NOW(),@startState,@endState);
                end if;
              end if;
              if(@appIdx = 1) then
                 insert into aux_studentAndState(requestId,rollNumber,fromState,toState,appId,applicationPurpose) values(NEW.requestId,NEW.userId,@startState,@endState,@appcntId,NEW.applicationPurpose);
                 insert into applicationProcess.aux_requestStateTransitions(requestId,fromState,toState,userId,appId,requestArrivalTime,remark,params,applicationPurpose) values(NEW.requestId,@startState,@endState,NEW.userId,@appcntId,NEW.requestArrivalTime,NEW.remark,@string,NEW.applicationPurpose);
                insert into applicationProcess.requestStateTransitions(requestId,fromState,toState,userId,requestArrivalTime,remark,params,applicationPurpose) values(NEW.requestId,@startState,@endState,NEW.userId,NEW.requestArrivalTime,NEW.remark,@string,NEW.applicationPurpose);
                insert into userInputDatabase.outputResults(requestId,timet,output) values(NEW.requestId,NOW(),(select concat(@startState,",",@endState)));
              else
                  insert into aux_studentAndState(requestId,rollNumber,fromState,toState,appId) values(NEW.requestId,NEW.userId,@startState,@endState,@appcntId);
                  insert into applicationProcess.aux_requestStateTransitions(requestId,fromState,toState,userId,appId,requestArrivalTime,remark,params) values(NEW.requestId,@startState,@endState,NEW.userId,@appcntId,NEW.requestArrivalTime,NEW.remark,@string);
                  insert into applicationProcess.requestStateTransitions(requestId,fromState,toState,userId,requestArrivalTime,remark,params) values(NEW.requestId,@startState,@endState,NEW.userId,NEW.requestArrivalTime,NEW.remark,@string);
                  insert into userInputDatabase.outputResults(requestId,timet,output) values(NEW.requestId,NOW(),(select concat(@startState,",",@endState)));
              end if;
         else
               insert into userInputDatabase.outputErrorMsgs(requestId,timet,msgId,msg) values(NEW.requestId,NEW.requestArrivalTime,(select msgId from userInputDatabase.messagesForUsersDomain where msgId=@startState),(select msgForAcomplish from userInputDatabase.messagesForUsersDomain where msgId=@startState));
         end if;
         end if;
         end if;
       end if;
    else
           insert into userInputDatabase.outputErrorMsgs(requestId,timet,msgId,msg) values(NEW.requestId,NEW.requestArrivalTime,(select msgId from userInputDatabase.messagesForUsersDomain where msgId=@startState),(select msgAboutUserAuthentication from userInputDatabase.messagesForUsersDomain where msgId=@startState));

    end if;
  END;

  |
delimiter ;
