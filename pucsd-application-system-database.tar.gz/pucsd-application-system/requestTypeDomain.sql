insert into requestTypeDomain(requestTypeId,requestType) values(1,"insert"),(2,"delete"),(3,"update"),(4,"select");
