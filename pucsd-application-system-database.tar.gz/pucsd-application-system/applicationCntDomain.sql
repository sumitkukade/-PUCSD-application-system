insert into applicationCntDomain (appId,appcnt) values("APBN",16),("APIB",16),("APFS",8),("APND",8);

/*(appId,appcnt) values("APND",3);*/
