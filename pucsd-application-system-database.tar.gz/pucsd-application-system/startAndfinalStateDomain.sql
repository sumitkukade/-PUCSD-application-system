insert into startAndfinalStateDomain(applicationState) values("Start"),("Finish"),("ApplicationRejectedByOffice");
