insert into applicationPurposeDomain(applicationPurpose) values ("Jaykar Library"),("Gymnasium"),("Bus Pass"),("Scholarship Form"),("Education Loan"),("Cast-validity"),("Non-creamy Layer");
