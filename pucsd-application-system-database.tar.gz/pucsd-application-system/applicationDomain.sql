insert into applicationDomain(appId,appindex,appDesc) values("APBN",1,"Bonafide Certificate");
insert into applicationDomain(appId,appindex,appDesc) values("APIB",2,"International Bonafide Certificate");
insert into applicationDomain(appId,appindex,appDesc) values("APFS",3,"Fee Structure Certificate For Bank");
insert into applicationDomain(appId,appindex,appDesc) values("APND",4,"No Dues Certificate");
