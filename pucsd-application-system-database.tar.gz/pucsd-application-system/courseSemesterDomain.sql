insert into courseSemesterDomain(courseId,year,semId) values("MCA",1,1),("MCA",1,2),("MCA",2,3),("MCA",2,4),("MCA",3,5),("MCA",3,6),("MSC",1,1),("MSC",1,2),("MSC",2,3),("MSC",2,4);
