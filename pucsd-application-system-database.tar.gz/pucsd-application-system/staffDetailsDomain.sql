insert into staffDetailsDomain(staffId,qualification,address) values("staff1-Abhijit","MA","pune");
insert into staffDetailsDomain(staffId,qualification,address) values("staff2-Amar","MA","pune");
