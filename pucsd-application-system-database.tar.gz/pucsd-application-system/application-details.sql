SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

DROP TABLE IF EXISTS courseDomain;
DROP TABLE IF EXISTS courceSemesterDomain;
DROP TABLE IF EXISTS reqeustTypeDomain;
DROP TABLE IF EXISTS tableIdDomain;
DROP TABLE IF EXISTS applicationDomain;
DROP TABLE IF EXISTS studentDetailsDomain;


/* ---------------------------------------------------------  */

/* courseId and year */

CREATE TABLE IF NOT EXISTS courseDomain (
  courseId varchar(3) NOT NULL,
  year varchar(1) NOT NULL,
  Constraint pk_courseDomain Primary Key(courseId,year)
);

/* ---------------------------------------------------------  */

/*courseId with semester */

CREATE TABLE IF NOT EXISTS courseSemesterDomain (
  courseId varchar(3) NOT NULL,
  year varchar(1) NOT NULL,
  semId varchar(1) NOT NULL,
  Constraint pk_courseSemesterDomain Primary Key(courseId,semId),
  Foreign Key(courseId,year) References courseDomain(courseId,year)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/* ---------------------------------------------------------  */

/* feesStructure for maharashtrian Student */

CREATE TABLE IF NOT EXISTS feesStructureDomain (
  category varchar(5) Not NULL,
  courseId varchar(3) NOT NULL,
  semId varchar(1) NOT NULL,
  tutionFee integer NOT NULL,
  labFee integer NOT NULL,
  otherFee integer NOT NULL,
  Constraint pk_feesStructureDomain Primary Key(category,courseId,semId),
  Foreign Key(courseId,semId) References courseSemesterDomain(courseId,semId)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/* ---------------------------------------------------------  */

/* feesStructure for non-maharashtrian Student */

CREATE TABLE IF NOT EXISTS feesStructureNonMaharashtrianDomain (
  category varchar(5) Not NULL,
  courseId varchar(3) NOT NULL,
  semId varchar(1) NOT NULL,
  tutionFee integer NOT NULL,
  labFee integer NOT NULL,
  otherFee integer NOT NULL,
  Constraint pk_feesStructureOmsStudentDomain Primary Key(category,courseId,semId),
  Foreign Key(courseId,semId) References courseSemesterDomain(courseId,semId)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/* ---------------------------------------------------------  */

/* feesStructure for international Student */

CREATE TABLE IF NOT EXISTS feesStructureForInternationalStudentDomain (
  category varchar(5) Not NULL,
  courseId varchar(3) NOT NULL,
  semId varchar(1) NOT NULL,
  tutionFee integer NOT NULL,
  labFee integer NOT NULL,
  otherFee integer NOT NULL,
  Constraint pk_feesStructureForInternationalStudentDomain Primary Key(category,courseId,semId),
  Foreign Key(courseId,semId) References courseSemesterDomain(courseId,semId)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/* ---------------------------------------------------------  */
/* applicationId and with its index and desc */

CREATE TABLE IF NOT EXISTS applicationDomain (
  appId varchar(5) NOT NULL,
  appindex varchar(2) NOT NULL,
  appDesc text NOT NULL,
  Constraint pk_applicationDomain Primary Key(appId,appindex)
);

/* ---------------------------------------------------------  */

CREATE TABLE IF NOT EXISTS applicationCntDomain (
  appId varchar(5) NOT NULL,
  appcnt integer NOT NULL,
  Constraint pk_applicationCntDomain Primary Key(appId,appcnt)
);

/* ---------------------------------------------------------  */

/* country name */

CREATE TABLE IF NOT EXISTS countriesDomain (
    countryId int(11) NOT NULL AUTO_INCREMENT,
    countrycode varchar(3) NOT NULL,
    countryName varchar(150) NOT NULL,
    phonecode int(11) NOT NULL,
    PRIMARY KEY (countryId)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=249 ;

/* ---------------------------------------------------------  */
/* stateName */
CREATE TABLE IF NOT EXISTS statesDomain (
    stateId int(11) NOT NULL AUTO_INCREMENT,
    stateName varchar(30) NOT NULL,
    countryId int(11) NOT NULL DEFAULT '1',
    PRIMARY KEY (stateId),
    Foreign Key (countryId) REFERENCES countriesDomain(countryId)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4121 ;


/* ---------------------------------------------------------  */

/* country and state name */

CREATE TABLE IF NOT EXISTS citiesDomain (
    cityId int(11) NOT NULL AUTO_INCREMENT,
    cityName varchar(30) NOT NULL,
    stateId int(11) NOT NULL,
    PRIMARY KEY (cityId,stateId),
    Foreign Key(stateId) REFERENCES statesDomain(stateId)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47577 ;


/* ---------------------------------------------------------  */

/* userId of applicationProcess*/

CREATE TABLE IF NOT EXISTS userIdDomain (
  userId varchar(15),
  Constraint pk_userIdDomain Primary Key(userId)
);

/* ---------------------------------------------------------  */

CREATE TABLE IF NOT EXISTS studentSignupDomain (
  signupId bigInt Primary key AUTO_INCREMENT,
  rollNumber varchar(15) NOT NULL
);

/* ---------------------------------------------------------  */

CREATE TABLE IF NOT EXISTS studentDetailsDomain (
  rollNumber varchar(15) NOT NULL,
  courseId varchar(3) NOT NULL,
  semId varchar(1) NOT NULL,
  category varchar(5) NOT NULL,
  fname text NOT NULL,
  mname text,
  lname text NOT NULL,
  email text NOT NULL,
  dateOfBirth date NOT NULL,
  contactNo varchar(10) NOT NULL,
  gender varchar(1) NOT NULL,
  domicile boolean NOT NULL,
  adderessLine1 varchar(50) NOT NULL,
  adderessLine2 varchar(50) NOT NULL,
  adderessLine3 varchar(50) NOT NULL,
  cityId int(11) NOT NULL,
  stateId int(11) NOT NULL,
  countryId int(11) NOT NULL,
  signupId bigInt NOT NULL,
  signupTime timestamp NOT NULL,
  Constraint pk_studentDetails Primary Key(rollNumber,signupId),
  Foreign Key (cityId,stateId) References citiesDomain(cityId,stateId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key (signupId) References studentSignupDomain(signupId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key (rollNumber) References userIdDomain(userId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key (countryId) References countriesDomain(countryId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key (category) References feesStructureDomain(category)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key (courseId) References courseDomain(courseId)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/* ---------------------------------------------------------  */

CREATE TABLE IF NOT EXISTS internationalStudentInformationDomain (
  rollNumber varchar(15) NOT NULL,
  nationality text NOT NULL,
  studentAddrInCity text NOT NULL,
  dateOfFirstAdmsn date NOT NULL,
  passportNo text NOT NULL,
  issuedOn date NOT NULL,
  passportValidTill date NOT NULL,
  visaNo text NOT NULL,
  visaType text NOT NULL,
  visaIssuedOn date NOT NULL,
  visaValidTill date NOT NULL,
  regularOrBacklog text,
  examDate date,
  resultDate  date,
  signupId bigint NOT NULL,
  signupTime timestamp NOT NULL,
  Constraint pk_internationalStudentInformationDomain Primary Key(rollNumber,signupId),
  Foreign Key (signupId) References studentSignupDomain(signupId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(rollNumber) References studentDetailsDomain(rollNumber)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/* ---------------------------------------------------------  */

CREATE TABLE IF NOT EXISTS staffDetailsDomain (
  staffId varchar(15),
  qualification text,
  address text,
  Constraint pk_statffDetailsDomain Primary Key(staffId),
  Foreign Key (staffId) References userIdDomain(userId)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/* ---------------------------------------------------------  */

/* all state eg. start */

CREATE TABLE IF NOT EXISTS applicationStateDomain (
  applicationState varchar(40) NOT NULL,
  Constraint pk_applicationState Primary Key(applicationState)
);

/* RequestFisnishedWithError---------------------------------------------------------  */

/* have two state start and final */


/*
eg.  start,ApplicationInitiated */

CREATE TABLE IF NOT EXISTS stateChangeDomain
(
  fromState varchar(40),
  toState varchar(40),
  Constraint pk_stateChangeDomain Primary Key(fromState,toState),
  Foreign key(fromState) References applicationStateDomain(applicationState)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign key(toState) References applicationStateDomain(applicationState)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/*---------------------------------------------------------  */
/* staff Action 
eg. ApplicationSubmitted,requestArrivedInOffice */

CREATE TABLE IF NOT EXISTS staffActionDomain (
  staffActionFrom varchar(40),
  staffActionTo varchar(40),
  Constraint pk_staffActionDomain Primary Key(staffActionFrom,staffActionTo),
  Foreign Key (staffActionFrom,staffActionTo) References stateChangeDomain(fromState,toState)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/*---------------------------------------------------------  */

/* student Action
eg.  start,ApplicationInitiated
*/
CREATE TABLE IF NOT EXISTS studentActionDomain (
  studentActionFrom varchar(40),
  studentActionTo varchar(40),
  Constraint pk_studentActionDomain Primary Key(studentActionFrom,studentActionTo),
  Foreign Key (studentActionFrom,studentActionTo) References stateChangeDomain(fromState,toState)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/*---------------------------------------------------------  */

/*requestId */

CREATE TABLE IF NOT EXISTS requestindex (
   requestId bigint NOT NULL,
   Constraint pk_requestindex Primary Key(requestId)
);

/*---------------------------------------------------------  */

/* this table for the when student request for certificate so he can know the his certificate is availble or not */

CREATE TABLE IF NOT EXISTS aux_studentAndState (
  requestId bigint NOT NULL,
  rollNumber varchar(15) NOT NULL,
  fromState varchar(40) NOT NULL,
  toState varchar(40) NOT NULL,
  appId varchar(5) NOT NULL,
  iplog text,
  applicationPdf blob(100000),
  applicationPurpose text,
  Constraint pk_aux_studentAndState Primary Key(requestId,rollNumber,fromState,toState,appId),
  Foreign Key(appId) References applicationDomain(appId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(rollNumber) References studentDetailsDomain(rollNumber)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(fromState,toState) References stateChangeDomain(fromState,toState)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/*---------------------------------------------------------  */

/* this table for only student so he can insert his current state and proceed */

CREATE TABLE IF NOT EXISTS applicationRequests (
  requestId bigInt NOT NULL,
  appId varchar(5) NOT NULL,
  userId varchar(15) NOT NULL,
  requestArrivalTime timestamp NOT NULL,
  remark text,
  params text,
  iplog text,
  applicationPdf blob(100000),
  applicationPurpose text,
  Constraint pk_applicationRequests Primary Key(requestId),
  Foreign Key(requestId) References requestindex(requestId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(appId) References applicationDomain(appId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(userId) References userIdDomain(userId)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/*---------------------------------------------------------  */

/* this table for only student so he can delete his  state and proceed */

CREATE TABLE IF NOT EXISTS aux_applicationRequestsDelete (
  requestId bigInt NOT NULL,
  appId varchar(5) NOT NULL,
  userId varchar(15) NOT NULL,
  requestArrivalTime timestamp NOT NULL,
  remark text,
  params text,
  applicationPurpose text,
  Constraint pk_aux_applicationRequestsDelete Primary Key(requestId),
  Foreign Key(requestId) References requestindex(requestId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(appId) References applicationDomain(appId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(userId) References userIdDomain(userId)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/*---------------------------------------------------------  */

/* this table for only student so he can update his  state and proceed */

CREATE TABLE IF NOT EXISTS aux_applicationRequestsUpdate (
  requestId bigInt NOT NULL,
  appId varchar(5) NOT NULL,
  userId varchar(15) NOT NULL,
  requestArrivalTime timestamp NOT NULL,
  remark text,
  params text,
  applicationPurpose text,
  Constraint pk_aux_applicationRequestsUpdate Primary Key(requestId),
  Foreign Key(requestId) References requestindex(requestId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(appId) References applicationDomain(appId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(userId) References userIdDomain(userId)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/*---------------------------------------------------------  */

CREATE TABLE IF NOT EXISTS aux_applicationRequestsUpdateRequestId (
  requestId bigInt NOT NULL,
  appId varchar(5) NOT NULL,
  userId varchar(15) NOT NULL,
  requestArrivalTime timestamp NOT NULL,
  remark text,
  params text,
  applicationPurpose text,
  Constraint pk_aux_applicationRequestsUpdateRequestId Primary Key(requestId),
  Foreign Key(requestId) References requestindex(requestId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(appId) References applicationDomain(appId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(userId) References userIdDomain(userId)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/*---------------------------------------------------------  */

/*---------------------------------------------------------  */
CREATE TABLE IF NOT EXISTS aux_applicationRequestsUpdateappId (
  requestId bigInt NOT NULL,
  appId varchar(5) NOT NULL,
  userId varchar(15) NOT NULL,
  requestArrivalTime timestamp NOT NULL,
  remark text,
  params text,
  applicationPurpose text,
  Constraint pk_aux_applicationRequestsUpdateappId Primary Key(requestId,appId),
  Foreign Key(requestId) References requestindex(requestId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(appId) References applicationDomain(appId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(userId) References userIdDomain(userId)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/*---------------------------------------------------------  */

CREATE TABLE IF NOT EXISTS modificationStateDomain (
  applicationState varchar(40) NOT NULL,
  Constraint pk_modificationStateDomain Primary Key(applicationState),
  Foreign key(applicationState) References applicationStateDomain(applicationState)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/*---------------------------------------------------------  */


/* this is for when application process is finish then all records from that table deletes and new record is inserted it helps for finding the duplicate state */

CREATE TABLE IF NOT EXISTS aux_requestStateTransitions (
  requestId bigInt NOT NULL,
  fromState varchar(40) NOT NULL,
  toState varchar(40) NOT NULL,
  userId varchar(15) NOT NULL,
  appId varchar(5) NOT NULL,
  requestArrivalTime timestamp NOT NULL,
  remark text,
  params text,
  applicationPurpose text,
  Constraint pk_aux_requestStateTransitions Primary Key(requestId,fromState,toState,userId),
  Foreign Key(appId) References applicationDomain(appId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(requestId) References requestindex(requestId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(fromState,toState) References stateChangeDomain(fromState,toState)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(userId) References userIdDomain(userId)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/*---------------------------------------------------------  */

/* here all requstId and within its request State */

CREATE TABLE IF NOT EXISTS requestStateTransitions (
  requestId bigInt NOT NULL,
  fromState varchar(40) NOT NULL,
  toState varchar(40) NOT NULL,
  userId varchar(15) NOT NULL,
  requestArrivalTime timestamp NOT NULL,
  remark text,
  params text,
  applicationPurpose text,
  Constraint pk_requestStateTransitions Primary Key(requestId,fromState,toState,userId),
  Foreign Key(requestId) References requestindex(requestId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(fromState,toState) References stateChangeDomain(fromState,toState)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(userId) References userIdDomain(userId)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/*---------------------------------------------------------  */

/* it is like queue for application form */

CREATE TABLE IF NOT EXISTS studentApplicationQueue (
  requestId bigInt NOT NULL,
  rollnumber varchar(15) NOT NULL,
  appId varchar(5) NOT NULL,
  requestArrivalTime timestamp NOT NULL,
  fromState varchar(40) NOT NULL,
  toState varchar(40) NOT NULL,
  applicationPurpose text,
  Constraint pk_studentApplicationQueue Primary Key(requestId,rollnumber,appId,fromState,toState,requestArrivalTime),
  Foreign Key(requestId) References requestindex(requestId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(appId) References applicationDomain(appId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(rollnumber) References studentDetailsDomain(rollnumber)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/*---------------------------------------------------------  */

/*applcation process by staff */

CREATE TABLE IF NOT EXISTS applicationRequestByStaff (
  requestId bigInt NOT NULL,
  appId varchar(5) NOT NULL,
  userId varchar(15) NOT NULL,
  requestArrivalTime timestamp NOT NULL,
  remark text,
  params text,
  iplog text,
  applicationPdf blob(100000),
  applicationPurpose text,
  Constraint pk_applicationRequestByStaff Primary Key(requestId),
  Foreign Key(requestId) References requestindex(requestId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(appId) References applicationDomain(appId)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  Foreign Key(userId) References staffDetailsDomain(staffId)
  ON DELETE RESTRICT ON UPDATE CASCADE
);

/*---------------------------------------------------------  */
CREATE TABLE IF NOT EXISTS studentApplicationCount (
    requestId bigInt NOT NULL,
    rollNumber varchar(15) NOT NULL,
    appId varchar(5) NOT NULL,
    appcnt integer default 0,
    Constraint pk_studentApplicationCount primary key(requestId,rollNumber,appId,appcnt),
    Foreign Key(requestId) References requestindex(requestId)
    ON DELETE RESTRICT ON UPDATE CASCADE,
    Foreign Key(rollNumber) References studentDetailsDomain(rollNumber)
    ON DELETE RESTRICT ON UPDATE CASCADE,
    Foreign Key(appId) References applicationDomain(appId)
    ON DELETE RESTRICT ON UPDATE CASCADE
);
