import MySQLdb
import re  
from mod_python import Session
from config_path import data

def split_uppercase(s):
            return re.sub(r'([^A-Z])([A-Z])', r'\1 \2',s)


def index(req):
    crpn=""

      
    session = Session.Session(req)
    try:
      rollno=session['rno']
    except:
        	return """<html>Session Expired<p><a href="../student-login.html"> LOGIN AGAIN</a></html>"""
  


    ip=session['ipaddr']
    session.save()
    session.cleanup()
    req.content_type = 'text/html'
    db = MySQLdb.connect(
    host="localhost",
    user=data.mysql_user,
    passwd=data.mysql_pswd,
    db="applicationProcess" )
    # prepare a cursor object using cursor() method
    cursor = db.cursor()
   

     
    ssw="""select appId from applicationProcess.applicationDomain;"""
    cursor.execute(ssw)
    ress=cursor.fetchall()
    ress=map(lambda x:x[0],ress);
    
    arry=[] 	
    
    for i in ress:
	if i=='APBN':
		ss="""select applicationPurpose from applicationProcess.applicationForm where rollNumber=%s and appid='APBN';"""
       	        cursor.execute(ss,(rollno,));
       	        val=cursor.fetchall()
       	        val=map(lambda x:x[0],val)	
		
		for i in list(set(val)):
    			ssw="""select toState from applicationProcess.aux_studentAndState where rollNumber=%s and appId='APBN' and applicationPurpose=%s order by requestId desc limit 1 ;"""
    			cursor.execute(ssw,(rollno,i))
    			ress1=cursor.fetchall()
    			ress1=map(lambda x:x[0],ress1)
     			
    			if len(ress1)!=0 and ress1[0]=='FormPrinted':
        	    		arry.append(i)
	else:
		ssw="""select toState from applicationProcess.aux_studentAndState where rollNumber=%s and appId='%s' order by requestId desc limit 1 ;"""%(rollno,i)
    		cursor.execute(ssw)
    		ress1=cursor.fetchall()
    		ress1=map(lambda x:x[0],ress1)
     
    		if len(ress1)!=0 and ress1[0]=='FormPrinted':
        	    arry.append(i)
    	       
    fo=open(data.path+"/project_data/nevtag1.html","r");
    fo=fo.read()
    req.write(fo)
    
    if len(arry)!=0:
        docc=''
	
        for i in range(0,len(arry)):
        	qqq="""select appDesc from  applicationProcess.applicationDomain where appId='%s';"""%(str(arry[i])) 	
		cursor.execute(qqq)
        	ans=cursor.fetchall()
	
		
		if len(ans)==0:
		   ans="Bonafide Certificate For %s"%(arry[i])
		else:
		    ans=map(lambda x:x[0],ans)[0]
		if len(arry)-1!=i:
        		docc+=ans+","
		else:
			docc+=ans;
        
        aa="""</br><html><MARQUEE><blink><font size=4><b>Your  <i><font color=\"red\">%s </font></i>Is Printed Please Visite Office Along With Your Id Card!!!</b></font></blink></MARQUEE></html>"""%(docc)
        req.write(aa)   
    
    q="""select fname,mname,lname from applicationProcess.studentDetailsDomain where rollNumber=%s;"""%(rollno)
    cursor.execute(q);
    nm=cursor.fetchall()
   
    if len(nm)==0:
       return """access denied!!"""	
    nm=nm[0]
    nm=' '.join(nm);
    nm=nm.title()
    req.write("<label>Name:</b></label><label>"+nm+"</label>")


    req.write('<b><p><label>Rollno: %s\n</b></label>' % session['rno'])

    
    db = MySQLdb.connect(
    host="localhost",
    user=data.mysql_user,
    passwd=data.mysql_pswd,
    db="userInputDatabase" )
    # prepare a cursor object using cursor() method
    cursor = db.cursor()
    # prepare a cursor object using cursor() method

    
    query="""DROP TABLE IF EXISTS StudentStatus;""";
    cursor.execute(query);
    table="""create table StudentStatus (RollNumber int,Documents varchar(50),Status varchar(50));""";
    cursor.execute(table);
   
    ss="""select appDesc from applicationProcess.applicationDomain """
    cursor.execute(ss);
    val=cursor.fetchall()
    appname=map(lambda x:x[0],val)
    
    
    ss="""select appId from applicationProcess.applicationDomain """
    cursor.execute(ss);
    val=cursor.fetchall()
    appid=map(lambda x:x[0],val)
        
    
    appl=['Bonafide Certificate','Fee Structure Certificate For Bank','International Bonafide Certificate','No Dues Certificate']
     
    
    for i in range(0,len(appid)):
      if appid[i]=='APBN':
       	ss="""select applicationPurpose from applicationProcess.applicationForm where rollNumber=%s and appid='APBN';"""
       	cursor.execute(ss,(rollno,));
       	val=cursor.fetchall()
       	val=map(lambda x:x[0],val)
        
        
        for j in list(set(val)):

                    ss="""select params,applicationPurpose from applicationProcess.requestStateTransitions where userId=%s and applicationPurpose=%s and params like %s"""
                    cursor.execute(ss,(rollno,j,appid[i]+'%'));
                    val=cursor.fetchall()
                    
                    if len(val)!=0:  
                        stsfm=str(val[len(val)-1]).split(',')[1]
                        ststo=str(val[len(val)-1]).split(',')[2]
                        val=map(lambda x:x,val)
                        dblcm=str(val[len(val)-1]).split(',')[4]
	                dblcm=map(lambda x:x, val[len(val)-1])[1]
	
                
                        if ststo=='ApplicationSubmitted':

                                            ss="""select fromState,toState from applicationProcess.aux_studentAndState where rollNumber=%s and appId=%s and applicationPurpose=%s  order by requestId desc limit 1 ;"""
                                            cursor.execute(ss,(rollno,appid[i],j));   
                                            ree=cursor.fetchall()
                                            ree=map(lambda x:x,ree)
                                            b=split_uppercase(ree[0][1])
                              
                                            if len(ree)!=0:
                   
                                                        ss="""insert into StudentStatus values(%s,%s,%s)"""
                                                        cursor.execute(ss,(rollno,appname[i]+" For "+dblcm,b))
                                                        db.commit();
                                
                        else:
                                                b=split_uppercase(ststo)
                                                ss="""insert into StudentStatus values(%s,%s,%s)"""
                                                cursor.execute(ss,(rollno,appname[i]+" For "+dblcm,b));
                                                db.commit();
	
        
      else:
       
       ss="""select params,applicationPurpose from applicationProcess.requestStateTransitions where userId=%s and params like %s"""
       cursor.execute(ss,(rollno,appid[i]+'%'));
       val=cursor.fetchall()

       if len(val)!=0:  
                stsfm=str(val[len(val)-1]).split(',')[1]
                ststo=str(val[len(val)-1]).split(',')[2]
                val=map(lambda x:x,val)
                dblcm=str(val[len(val)-1]).split(',')[4]
	        dblcm=map(lambda x:x, val[len(val)-1])[1]
	         
                
                if ststo=='ApplicationSubmitted':
                             	
                         
                              ss="""select fromState,toState from applicationProcess.aux_studentAndState where rollNumber=%s and appId=%s   order by requestId desc limit 1 ;"""
                              cursor.execute(ss,(rollno,appid[i]));   
                              ree=cursor.fetchall()
                              ree=map(lambda x:x,ree)
                              b=split_uppercase(ree[0][1])
                              b=b.strip()
                                
                              if len(ree)!=0:
                                      
                                      ss="""insert into StudentStatus values(%s,%s,%s)"""
                                      cursor.execute(ss,(rollno,appname[i],b))
                                      db.commit();
                                      
                                
                else:
                      b=split_uppercase(ststo)
                      ss="""insert into StudentStatus values(%s,%s,%s)"""
                      cursor.execute(ss,(rollno,appname[i],b));
                      db.commit();
    
   
    
  
    
  
            
    










        
    cursor.execute(""" select * from StudentStatus;""");
    val=cursor.fetchall()
    names = list(map(lambda x: x[0], cursor.description))
    db.close() 
    fp1=open(data.path+"/project_data/json.txt","w");
    fp1.write("[");
    for i in range(0,len(val)):
        fp1.write("{");
    	for n in range(0,len(names)):
		fp1.write("\""+str(names[n])+"\":");
		if str(val[i][n]).isdigit():
                	fp1.write(str(val[i][n]));
		else:
	                fp1.write("\""+str(val[i][n])+"\"");
		
		if not n==len(names)-1:
		  fp1.write(",\n");
	if not i==len(val)-1:
        	fp1.write("},\n");
	else:
		fp1.write("}	\n");
		

    fp1.write("]");
   
    
    #crp=open(data.path+"/project_data/sample.html","r");
    #crpn+=crp.read()
    db = MySQLdb.connect(
    host="localhost",
    user=data.mysql_user,
    passwd=data.mysql_pswd,
    db="userInputDatabase" )
    # prepare a cursor object using cursor() method
    cursor = db.cursor()
    ss="""select output from outputResults;"""
    cursor.execute(ss)
    apsts=cursor.fetchall()
    req.content_type="text/html"
    
    db = MySQLdb.connect(
    host="localhost",
    user=data.mysql_user,
    passwd=data.mysql_pswd,
    db="userInputDatabase" )
    db.close()
    
   

    ss=""" select rollNumber from applicationProcess.internationalStudentInformationDomain;"""
    cursor.execute(ss)
    rnoarray=cursor.fetchall()
    rno=map(lambda x:x[0],rnoarray)
    
    if str(rollno)in rno:
            fp=open(data.path+"/project_data/NewAppInter.html","r")
            crpn+=fp.read()
            
    else:
            fp=open(data.path+"/project_data/Newapplication.html","r")
            crpn+=fp.read()
     
    crpn2=open(data.path+"/project_data/student.html","r");
    crpn+=crpn2.read()

    crpn+="<table border=1 class=\"myTable\">"
    for i in names:
      crpn+="<th >%s </th>"%(i)    
    crpn+="<tr>"
    for i in names:
	crpn+="<td><input ng-model=\"ch.%s\" placeholder=%s></td>"%(i,i) 
    
    crpn+="</tr>"
    crpn+="<tr style=\"width:100px;\" ng-repeat=\"chrp in chiarperson|filter:ch|filter:statuspa|filter:fname\">"
    
    lnt=len(names);
    
                         
    for n in range(0,len(names)):
                               	 crpn+="<td>{{chrp.%s}}"%(names[n]);
                                 
                                 if names[n]=="Status":
                                   crpn+="<td ng-if=\"chrp.Status==\'Application Form Filled\' && (chrp.Documents!=\'Fee Structure Certificate For Bank\' && chrp.Documents!=\'International Bonafide Certificate\' && chrp.Documents!=\'No Dues Certificate\')\"></form><form value=\"form\" action=\"read_pur.py\" method=\"post\"><input type=hidden name=\'edit\' value={{chrp.Documents}}><input type=hidden name=\"e\" value=1><input type=submit value=Edit></form><form value=\"form\" action=\"st_loh.py/print_Application_stud\" method=\"post\"><input type=hidden name=\'prps\' value={{chrp.Documents}}><input type=submit value=Submit><input type=hidden name=\"ff\" value=\"0\"></form><form value=\"form\" action=\"./delete.py\" method=\"post\"><input type=hidden name=\'prps\' value={{chrp.Documents}}><input type=\"submit\" value=\"Delete\"><input type=\"hidden\" name=\"appid\" value=\"APBN\"></form></td>"
                                   
                                   crpn+="<td ng-if=\"chrp.Status==\'Application Form Filled\' && chrp.Documents==\'Fee Structure Certificate For Bank\'\"></form><form value=\"form\" action=\"read_bank.py\" method=\"post\"><input type=hidden name=\"edit\" value=1><input type=submit value=Edit></form><form value=\"form\" action=\"st_loh.py/print_Application_stud\" method=\"post\"><input type=submit value=Submit><input type=hidden name=\"ff\" value=\"2\"></form><form value=\"form\" action=\"./delete.py\" method=\"post\"><input type=\"submit\" value=\"Delete\"><input type=\"hidden\" name=\"appid\" value=\"APFS\"></form></td>" 
                                   crpn+="<td ng-if=\"chrp.Status==\'Application Form Filled\' && chrp.Documents==\'No Dues Certificate\'\"><form value=\"form\" action=\"st_loh.py/print_Application_stud\" method=\"post\"><input type=submit value=Submit><input type=hidden name=\"ff\" value=\"1\"></form><form value=\"form\" action=\"./delete.py\" method=\"post\"><input type=\"submit\" value=\"Delete\"><input type=\"hidden\" name=\"appid\" value=\"APND\"></form></td>"
                                   crpn+="<td ng-if=\"chrp.Status==\'Application Form Filled\' && chrp.Documents==\'International Bonafide Certificate\'\"><form value=\"form\" action=\"st_loh.py/print_Application_stud\" method=\"post\"><input type=submit value=Submit><input type=hidden name=\"ff\" value=\"3\"></form><form value=\"form\" action=\"./delete.py\" method=\"post\"><input type=\"submit\" value=\"Delete\"><input type=\"hidden\" name=\"appid\" value=\"APIB\"></form></td>"
                                   
                                   crpn+="<td ng-if=\"chrp.Status==\'Application Form Partially Filled\' && chrp.Documents==\'Bonafide Certificate\'\"><form value=\"form\" action=\"read_pur.py\" method=\"post\"><input type=submit value=Edit></form><form value=\"form\" action=\"./delete.py\" method=\"post\"><input type=hidden name=\'prps\' value={{chrp.Documents}}><input type=\"submit\" value=\"Delete\"><input type=\"hidden\" name=\"appid\" value=\"APBN\"></form></td>"
                                   
                                   crpn+="<td ng-if=\"chrp.Status==\'Application Form Partially Filled\' && chrp.Documents==\'Fee Structure Certificate For Bank\'\"><form value=\"form\" action=\"read_bank.py\" method=\"post\"><input type=submit value=Edit><input type=hidden name=\"edit\" value=1></form><form value=\"form\" action=\"./delete.py\" method=\"post\"><input type=\"submit\" value=\"Delete\"><input type=\"hidden\" name=\"appid\" value=\"APFS\"></form></td>"
                                   return """<html>%s</html>"""%(crpn)
                       
def print_Application_stud(req):
           
           session = Session.Session(req);
           Rollno=session['rno']
           ip=session['ipaddr']
           session.save()
           session.cleanup()
           tabid="ApplicationRequests"
           db = MySQLdb.connect(
    	   host="localhost",
    	   user=data.mysql_user,
    	   passwd=data.mysql_pswd,
    	
           db="userInputDatabase" )
   	   #prepare a cursor object using cursor() method
    	   cursor = db.cursor()
           info=req.form
           
           ff=int(info['ff'])
           if ff==0:
           	prps=info['prps']
	        
                prps=prps.split('Bonafide Certificate For')[1].strip()
           else:
		prps=''
           arrayid=["APBN,ApplicationFormFilled,ApplicationSubmitted,Bonafide Certificate,%s"%(prps),"APND,ApplicationFormFilled,ApplicationSubmitted,No Dues Certificate,apply for No Dues Certificate"
,"APFS,ApplicationFormFilled,ApplicationSubmitted,Fee Structure Certificate For Bank,apply for Fee Structure Certificate For Bank","APIB,ApplicationFormFilled,ApplicationSubmitted,International Bonafide Certificate,apply for International Bonafide Certificate","APBN,ApplicationFormFilled,ApplicationSubmitted,Bonafide Certificate,apply for Bonafide Certificate"]
           
           psid=arrayid[ff]
           appid=psid.split(',')[0]
           aplydc=psid.split(',');
           aplydc=aplydc[3:]
           	
           ss="""select fromState,toState from applicationProcess.requestStateTransitions where userId=%s and params like %s;"""
           cursor.execute(ss,(Rollno,appid+'%'))
           val=cursor.fetchall()
           states=val[len(val)-1]
           
           if states==('ApplicationFormFilled','ApplicationFormPartiallyFilled'):
           	 flg=1
                 apl=','.join(applydc)
	  	 ss="""insert into userInputDatabase.inputRequests(requestTime,requestType,userId,tableId,iplog,params) values (NOW(),"insert",%s,%s,%s,%s);"""
                 
                 cursor.execute(ss,(Rollno,tabid,iplog,appid+",ApplicationFormFilled,ApplicationFormFilled,"+apl))
         	 db.commit();




           ss="""insert into userInputDatabase.inputRequests(requestTime,requestType,userId,tableId,iplog,params) values (NOW(),"insert",%s,%s,%s,%s);"""
           cursor.execute(ss,(Rollno,tabid,ip,psid))
       	   db.commit();
           
           
           fp=open(data.path+"/project_data/autoclick4.html")
           fp=fp.read()   
           return fp

